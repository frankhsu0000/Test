# Redesigned-Discord-Octo-Robot
Gives updates on discord.
